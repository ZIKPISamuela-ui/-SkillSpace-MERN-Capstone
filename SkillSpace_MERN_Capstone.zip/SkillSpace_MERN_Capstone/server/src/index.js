import express from "express";
import mongoose from "mongoose";
import cors from "cors";
import dotenv from "dotenv";
import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken";
import { User, Course } from "./models.js";
import { protect, adminOnly } from "./middleware.js";

dotenv.config();
const app = express();
app.use(cors({ origin: process.env.CLIENT_URL || "http://localhost:5173" }));
app.use(express.json());

const tokenFor = id => jwt.sign({ id }, process.env.JWT_SECRET, { expiresIn: "7d" });
const safeUser = user => ({
  id: user._id, name: user.name, email: user.email, role: user.role,
  enrolledCourses: user.enrolledCourses
});

app.get("/api/health", (_req, res) => res.json({ status: "ok", app: "SkillSpace API" }));

app.post("/api/auth/register", async (req, res) => {
  try {
    const { name, email, password } = req.body;
    if (!name || !email || !password) return res.status(400).json({ message: "Name, email and password are required." });
    if (password.length < 6) return res.status(400).json({ message: "Password must be at least 6 characters." });
    if (await User.findOne({ email })) return res.status(409).json({ message: "An account with this email already exists." });
    const user = await User.create({ name, email, password: await bcrypt.hash(password, 10) });
    res.status(201).json({ token: tokenFor(user._id), user: safeUser(user) });
  } catch (e) { res.status(500).json({ message: "Could not create account." }); }
});

app.post("/api/auth/login", async (req, res) => {
  try {
    const user = await User.findOne({ email: req.body.email });
    if (!user || !(await bcrypt.compare(req.body.password || "", user.password)))
      return res.status(401).json({ message: "Invalid email or password." });
    res.json({ token: tokenFor(user._id), user: safeUser(user) });
  } catch { res.status(500).json({ message: "Login failed." }); }
});

app.get("/api/auth/me", protect, (req, res) => res.json({ user: safeUser(req.user) }));

app.get("/api/courses", async (_req, res) => {
  try { res.json(await Course.find().sort({ createdAt: -1 })); }
  catch { res.status(500).json({ message: "Could not load courses." }); }
});

app.get("/api/courses/:id", async (req, res) => {
  try {
    const course = await Course.findById(req.params.id);
    if (!course) return res.status(404).json({ message: "Course not found." });
    res.json(course);
  } catch { res.status(400).json({ message: "Invalid course ID." }); }
});

app.post("/api/courses/:id/enroll", protect, async (req, res) => {
  try {
    const course = await Course.findById(req.params.id);
    if (!course) return res.status(404).json({ message: "Course not found." });
    if (!req.user.enrolledCourses.some(id => id.equals(course._id))) {
      req.user.enrolledCourses.push(course._id);
      await req.user.save();
    }
    res.json({ message: "You are enrolled!", user: safeUser(req.user) });
  } catch { res.status(400).json({ message: "Could not enroll in this course." }); }
});

app.delete("/api/courses/:id/enroll", protect, async (req, res) => {
  req.user.enrolledCourses = req.user.enrolledCourses.filter(id => id.toString() !== req.params.id);
  await req.user.save();
  res.json({ message: "Course removed from your learning list.", user: safeUser(req.user) });
});

// Admin course management: promote a user to admin manually in MongoDB.
app.post("/api/courses", protect, adminOnly, async (req, res) => {
  try {
    const { title, category, description, level, duration, icon } = req.body;
    if (!title || !category || !description) return res.status(400).json({ message: "Title, category and description are required." });
    res.status(201).json(await Course.create({ title, category, description, level, duration, icon }));
  } catch { res.status(400).json({ message: "Could not create course." }); }
});

app.delete("/api/courses/:id", protect, adminOnly, async (req, res) => {
  try {
    await Course.findByIdAndDelete(req.params.id);
    await User.updateMany({}, { $pull: { enrolledCourses: req.params.id } });
    res.json({ message: "Course deleted." });
  } catch { res.status(400).json({ message: "Could not delete course." }); }
});

const port = process.env.PORT || 5000;
mongoose.connect(process.env.MONGO_URI)
  .then(() => {
    console.log("MongoDB connected");
    app.listen(port, () => console.log(`SkillSpace API running on port ${port}`));
  })
  .catch(err => { console.error("MongoDB connection failed:", err.message); process.exit(1); });
