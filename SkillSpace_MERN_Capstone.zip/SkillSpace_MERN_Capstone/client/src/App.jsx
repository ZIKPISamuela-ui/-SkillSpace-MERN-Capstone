import { useEffect, useMemo, useState } from "react";
import { BookOpen, Search, LogOut, GraduationCap, Plus, Trash2, X, Menu, Sparkles, Clock3, CheckCircle2 } from "lucide-react";

const API = import.meta.env.VITE_API_URL || "http://localhost:5000/api";
const request = async (path, options = {}, token = "") => {
  const res = await fetch(`${API}${path}`, {
    ...options,
    headers: { "Content-Type": "application/json", ...(token ? { Authorization: `Bearer ${token}` } : {}), ...options.headers }
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data.message || "Something went wrong.");
  return data;
};

export default function App() {
  const [token, setToken] = useState(localStorage.getItem("ss_token") || "");
  const [user, setUser] = useState(JSON.parse(localStorage.getItem("ss_user") || "null"));
  const [courses, setCourses] = useState([]);
  const [query, setQuery] = useState("");
  const [category, setCategory] = useState("All");
  const [tab, setTab] = useState("Explore");
  const [modal, setModal] = useState("");
  const [authMode, setAuthMode] = useState("login");
  const [form, setForm] = useState({ name: "", email: "", password: "" });
  const [courseForm, setCourseForm] = useState({ title: "", category: "", description: "", level: "Beginner", duration: "4 weeks", icon: "📘" });
  const [notice, setNotice] = useState("");
  const [busy, setBusy] = useState(false);
  const [mobileNav, setMobileNav] = useState(false);

  const loadCourses = async () => {
    try { setCourses(await request("/courses")); }
    catch (e) { setNotice(e.message); }
  };
  useEffect(() => { loadCourses(); }, []);
  useEffect(() => {
    if (!token) return;
    request("/auth/me", {}, token).then(d => setUser(d.user)).catch(() => logout());
  }, []);

  const enrolled = useMemo(() => courses.filter(c => user?.enrolledCourses?.some(id => String(id) === String(c._id))), [courses, user]);
  const categories = ["All", ...new Set(courses.map(c => c.category))];
  const visible = courses.filter(c =>
    (category === "All" || c.category === category) &&
    `${c.title} ${c.description} ${c.category}`.toLowerCase().includes(query.toLowerCase()) &&
    (tab !== "My Learning" || enrolled.some(e => e._id === c._id))
  );

  function saveSession(data) {
    localStorage.setItem("ss_token", data.token);
    localStorage.setItem("ss_user", JSON.stringify(data.user));
    setToken(data.token); setUser(data.user); setModal(""); setForm({ name: "", email: "", password: "" });
    setNotice(`Welcome${data.user.name ? `, ${data.user.name.split(" ")[0]}` : ""}!`);
  }
  function logout() {
    localStorage.removeItem("ss_token"); localStorage.removeItem("ss_user");
    setToken(""); setUser(null); setTab("Explore"); setNotice("You have been logged out.");
  }
  async function submitAuth(e) {
    e.preventDefault(); setBusy(true);
    try {
      const data = await request(`/auth/${authMode}`, { method: "POST", body: JSON.stringify(form) });
      saveSession(data);
    } catch (e) { setNotice(e.message); }
    finally { setBusy(false); }
  }
  async function enroll(course) {
    if (!token) { setAuthMode("login"); setModal("auth"); return; }
    try {
      const data = await request(`/courses/${course._id}/enroll`, { method: "POST" }, token);
      setUser(data.user); localStorage.setItem("ss_user", JSON.stringify(data.user));
      setNotice(`Added ${course.title} to My Learning.`);
    } catch (e) { setNotice(e.message); }
  }
  async function removeCourse(course) {
    try {
      const data = await request(`/courses/${course._id}/enroll`, { method: "DELETE" }, token);
      setUser(data.user); localStorage.setItem("ss_user", JSON.stringify(data.user));
      setNotice("Course removed from your learning list.");
    } catch (e) { setNotice(e.message); }
  }
  async function createCourse(e) {
    e.preventDefault();
    try {
      await request("/courses", { method: "POST", body: JSON.stringify(courseForm) }, token);
      setCourseForm({ title: "", category: "", description: "", level: "Beginner", duration: "4 weeks", icon: "📘" });
      setModal(""); await loadCourses(); setNotice("Course published successfully.");
    } catch (e) { setNotice(e.message); }
  }
  async function deleteCourse(course) {
    if (!confirm(`Delete "${course.title}"?`)) return;
    try { await request(`/courses/${course._id}`, { method: "DELETE" }, token); await loadCourses(); setNotice("Course deleted."); }
    catch (e) { setNotice(e.message); }
  }

  return <div className="app-shell">
    <header className="topbar">
      <a className="brand" href="#" onClick={() => { setTab("Explore"); setCategory("All"); }}>
        <span className="brand-icon"><GraduationCap size={22}/></span><span>skill<span className="brand-accent">space</span><small>LEARNING HUB</small></span>
      </a>
      <button className="mobile-toggle" onClick={() => setMobileNav(!mobileNav)}><Menu/></button>
      <nav className={mobileNav ? "nav open" : "nav"}>
        <button className={tab === "Explore" ? "nav-link active" : "nav-link"} onClick={() => {setTab("Explore");setMobileNav(false);}}>Explore</button>
        <button className={tab === "My Learning" ? "nav-link active" : "nav-link"} onClick={() => {setTab("My Learning");setMobileNav(false);}}>My Learning</button>
      </nav>
      <div className="top-actions">
        {user ? <><div className="user-chip"><span className="avatar">{user.name?.[0]?.toUpperCase() || "S"}</span><span>{user.name}</span></div><button className="icon-btn" title="Log out" onClick={logout}><LogOut size={18}/></button></>
          : <><button className="btn-ghost" onClick={() => {setAuthMode("login");setModal("auth");}}>Log in</button><button className="btn-primary small" onClick={() => {setAuthMode("register");setModal("auth");}}>Get started</button></>}
      </div>
    </header>

    <main>
      <section className="hero">
        <div className="hero-glow"></div><div className="hero-content">
          <div className="eyebrow"><Sparkles size={14}/> YOUR JOURNEY STARTS HERE</div>
          <h1>Explore skills.<br/><span>Build your future.</span></h1>
          <p>Learn something new, grow your confidence, and turn your curiosity into real-world skills.</p>
          <button className="btn-primary" onClick={() => document.getElementById("catalog")?.scrollIntoView({behavior:"smooth"})}>Explore courses <span>↗</span></button>
          <div className="hero-stats"><div><strong>{courses.length.toString().padStart(2,"0")}+</strong><span>Learning paths</span></div><i></i><div><strong>{enrolled.length.toString().padStart(2,"0")}</strong><span>Your courses</span></div><i></i><div><strong>100%</strong><span>Curiosity</span></div></div>
        </div>
        <div className="hero-art"><div className="orbit orbit-one"></div><div className="orbit orbit-two"></div><div className="floating-card card-top"><span>✦</span><div><b>Keep growing</b><small>One lesson at a time</small></div></div><div className="book-illustration"><div className="book-back"></div><div className="book-front"><BookOpen size={58}/><span>LEARN<br/>ANYTHING</span></div><div className="sparkle s1">✦</div><div className="sparkle s2">✧</div></div><div className="floating-card card-bottom"><div className="mini-progress"><span></span></div><div><b>Your next chapter</b><small>Starts today</small></div></div></div>
      </section>

      <section className="catalog" id="catalog">
        <div className="section-heading"><div><div className="eyebrow muted">THE LIBRARY</div><h2>{tab === "My Learning" ? "Your learning space" : "Find your next skill"}</h2><p>{tab === "My Learning" ? "Pick up where you left off." : "Handpicked starting points for curious minds."}</p></div>
          <div className="search-box"><Search size={17}/><input value={query} onChange={e=>setQuery(e.target.value)} placeholder="Search courses..."/></div>
        </div>
        <div className="filters">{categories.map(c=><button key={c} className={category===c?"filter active":"filter"} onClick={()=>setCategory(c)}>{c}</button>)}
          {user?.role === "admin" && <button className="btn-primary add-btn" onClick={()=>setModal("course")}><Plus size={16}/> Add course</button>}
        </div>
        {visible.length ? <div className="course-grid">{visible.map((course,i)=><article className="course-card" key={course._id}>
          <div className={`course-art art-${i%4}`}><span className="course-emoji">{course.icon || "📘"}</span><span className="course-category">{course.category}</span><span className="art-number">0{i+1}</span></div>
          <div className="course-info"><div className="course-meta"><span>{course.level || "Beginner"}</span><span><Clock3 size={13}/> {course.duration || "4 weeks"}</span></div><h3>{course.title}</h3><p>{course.description}</p>
            <div className="course-footer">{user?.enrolledCourses?.some(id=>String(id)===String(course._id)) ? <button className="enrolled-btn" disabled><CheckCircle2 size={16}/> Enrolled</button> : <button className="text-btn" onClick={()=>enroll(course)}>Start learning <span>→</span></button>}
              {user?.role==="admin" && <button className="delete-btn" title="Delete course" onClick={()=>deleteCourse(course)}><Trash2 size={15}/></button>}
            </div>
          </div></article>)}</div> : <div className="empty"><div>✧</div><h3>{tab==="My Learning"?"Your learning journey is waiting":"No courses found"}</h3><p>{tab==="My Learning"?"Explore the library and enroll in your first course.":"Try another search or category."}</p><button className="btn-primary" onClick={()=>{setTab("Explore");setCategory("All");setQuery("");}}>Explore courses</button></div>}
      </section>
      <section className="bottom-cta"><div><span className="eyebrow">SMALL STEPS, BIG THINGS</span><h2>Your future is a skill away.</h2><p>Stay curious. Keep learning. Make it happen.</p></div><div className="cta-star">✳</div></section>
    </main>
    <footer><a className="brand footer-brand" href="#"><span className="brand-icon"><GraduationCap size={19}/></span><span>skill<span className="brand-accent">space</span><small>LEARNING HUB</small></span></a><span>© {new Date().getFullYear()} SkillSpace. Learn at your own pace.</span></footer>

    {notice && <div className="toast" onClick={()=>setNotice("")}>{notice}<button><X size={14}/></button></div>}
    {modal && <div className="modal-backdrop" onClick={()=>setModal("")}><div className="modal" onClick={e=>e.stopPropagation()}><button className="modal-close" onClick={()=>setModal("")}><X/></button>
      {modal==="auth" ? <><div className="modal-icon"><GraduationCap/></div><h2>{authMode==="login"?"Welcome back":"Create your account"}</h2><p className="modal-sub">{authMode==="login"?"Continue your learning journey.":"Join SkillSpace and start learning today."}</p><form onSubmit={submitAuth}>
        {authMode==="register" && <label>Full name<input required value={form.name} onChange={e=>setForm({...form,name:e.target.value})} placeholder="Your name"/></label>}
        <label>Email address<input required type="email" value={form.email} onChange={e=>setForm({...form,email:e.target.value})} placeholder="you@example.com"/></label>
        <label>Password<input required minLength="6" type="password" value={form.password} onChange={e=>setForm({...form,password:e.target.value})} placeholder="At least 6 characters"/></label>
        <button className="btn-primary full" disabled={busy}>{busy?"Please wait...":authMode==="login"?"Log in":"Create account"}</button></form><p className="switch-auth">{authMode==="login"?"New to SkillSpace?":"Already have an account?"} <button onClick={()=>setAuthMode(authMode==="login"?"register":"login")}>{authMode==="login"?"Sign up":"Log in"}</button></p></>
      : <><div className="modal-icon"><Plus/></div><h2>Publish a course</h2><p className="modal-sub">Add a new learning path to the library.</p><form onSubmit={createCourse}>
        <label>Course title<input required value={courseForm.title} onChange={e=>setCourseForm({...courseForm,title:e.target.value})}/></label>
        <label>Category<input required value={courseForm.category} onChange={e=>setCourseForm({...courseForm,category:e.target.value})} placeholder="e.g. Programming"/></label>
        <label>Description<textarea required rows="3" value={courseForm.description} onChange={e=>setCourseForm({...courseForm,description:e.target.value})}/></label>
        <div className="form-row"><label>Level<select value={courseForm.level} onChange={e=>setCourseForm({...courseForm,level:e.target.value})}><option>Beginner</option><option>Intermediate</option><option>Advanced</option></select></label><label>Duration<input value={courseForm.duration} onChange={e=>setCourseForm({...courseForm,duration:e.target.value})}/></label></div>
        <button className="btn-primary full">Publish course</button></form></>}
    </div></div>}
  </div>;
}
