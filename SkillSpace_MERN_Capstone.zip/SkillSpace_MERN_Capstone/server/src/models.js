import mongoose from "mongoose";

const userSchema = new mongoose.Schema({
  name: { type: String, required: true, trim: true },
  email: { type: String, required: true, unique: true, lowercase: true, trim: true },
  password: { type: String, required: true },
  role: { type: String, enum: ["student", "admin"], default: "student" },
  enrolledCourses: [{ type: mongoose.Schema.Types.ObjectId, ref: "Course" }]
}, { timestamps: true });

const courseSchema = new mongoose.Schema({
  title: { type: String, required: true, trim: true },
  category: { type: String, required: true },
  description: { type: String, required: true },
  level: { type: String, default: "Beginner" },
  duration: { type: String, default: "4 weeks" },
  icon: { type: String, default: "📘" },
  lessons: [{ type: String }]
}, { timestamps: true });

export const User = mongoose.model("User", userSchema);
export const Course = mongoose.model("Course", courseSchema);
