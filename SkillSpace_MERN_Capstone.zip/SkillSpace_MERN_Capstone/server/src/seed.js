import mongoose from "mongoose";
import dotenv from "dotenv";
import { Course } from "./models.js";
dotenv.config();

const courses = [
  { title: "Web Development", category: "Development", description: "Learn how websites are planned and built with HTML, CSS, JavaScript and modern web tools.", level: "Beginner", duration: "6 weeks", icon: "💻", lessons: ["How the web works", "HTML foundations", "CSS layouts", "JavaScript basics", "Build a responsive page"] },
  { title: "Python Basics", category: "Programming", description: "Start programming with Python, from variables and conditions to functions and small projects.", level: "Beginner", duration: "4 weeks", icon: "🐍", lessons: ["Python setup", "Variables and data types", "Conditions and loops", "Functions", "Mini project"] },
  { title: "Introduction to AI", category: "Artificial Intelligence", description: "Understand artificial intelligence, machine learning concepts and practical everyday applications.", level: "Beginner", duration: "5 weeks", icon: "🤖", lessons: ["What is AI?", "Machine learning basics", "Data and models", "AI applications", "Responsible AI"] },
  { title: "Database Fundamentals", category: "Technology", description: "Understand databases, collections, queries and how applications store information.", level: "Beginner", duration: "3 weeks", icon: "🗄️", lessons: ["Database concepts", "SQL and NoSQL", "MongoDB documents", "CRUD operations"] }
];

try {
  await mongoose.connect(process.env.MONGO_URI);
  await Course.deleteMany({});
  await Course.insertMany(courses);
  console.log("Sample courses added.");
} catch (e) { console.error(e.message); }
finally { await mongoose.disconnect(); }
